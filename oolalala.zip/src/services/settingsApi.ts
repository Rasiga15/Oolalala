const BASE_URL = 'http://18.61.216.57:4500/api';

export interface Settings {
  fare_per_km_car: string;
  fare_per_km_van: string;
  fare_per_km_bus: string;
  fare_per_km_auto: string;
  fare_per_km_bike: string;
  cancellation_free_window_hours: string;
  cancellation_fee_percentage: string;
  platform_commission_percent: string;
  referral_bonus_rider: string;
  referral_bonus_partner: string;
}

export const fetchSettings = async (): Promise<Settings> => {
  const response = await fetch(`${BASE_URL}/settings`, {
    method: 'GET',
    headers: {
      'accept': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch settings: ${response.status}`);
  }

  return await response.json();
};

export const fetchPreferences = async (): Promise<string[]> => {
  const response = await fetch(`${BASE_URL}/master/preferences`, {
    method: 'GET',
    headers: {
      'accept': 'application/json',
    },
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch preferences: ${response.status}`);
  }

  const data = await response.json();
  return Array.isArray(data) ? data : ['Ladies only', 'Kids Only', 'Senior Citizens'];
};