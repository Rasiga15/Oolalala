import axios from 'axios';
import { ApiResponse, BASE_URL, handleApiError } from '../config/api';

// Interfaces
export interface OtpRequestPayload {
  mobile_number: string;
  purpose: 'register' | 'login' | 'reset';
}

export interface OtpVerifyPayload {
  mobile_number: string;
  otp_code: string;
  purpose: 'register' | 'login' | 'reset';
}

export interface OtpResponse {
  message: string;
  otp_log_id?: number;
}

export interface DriverFormData {
  first_name: string;
  last_name: string;
  mobile_number: string;
  mobile_otp_log_id: number;
  email_address?: string;
  email_otp_log_id?: number;
  gender?: string;
  date_of_birth: string;
  location?: string;
  profile_image?: File | null;
  driving_licence_number: string;
  driving_licence_front: File | null;
  driving_licence_back?: File | null;
  aadhaar_number?: string;
  aadhaar_front?: File | null;
}

export interface Driver {
  id: number;
  user_id: number;
  driver_code: string;
  partner_id: number;
  travel_agent_id: number | null;
  average_rating: string;
  record_status: string;
  created_by: number;
  updated_by: number | null;
  createdAt: string;
  updatedAt: string;
  user: {
    id: number;
    first_name: string;
    last_name: string;
    mobile_number: string;
    email_address: string | null;
    gender: string | null;
    date_of_birth: string | null;
    fcm_token: string | null;
    is_verified: boolean;
    is_email_verified: boolean;
    role: string;
    publish_ride: boolean;
    referral_code: string | null;
    referred_by: string | null;
    profile_image_url: string | null;
    profile_image_verification_status: string;
    profile_image_verified_by: number | null;
    profile_image_verified_datetime: string | null;
    profile_image_rejection_reason: string | null;
    location: string | null;
    wallet_balance: string;
    record_status: string;
    created_by: number;
    updated_by: number | null;
    created_at: string;
    updated_at: string;
  };
}

export interface DriverCreateResponse {
  success: boolean;
  data?: {
    driver: Driver;
    temp_pin?: string;
  };
  message?: string;
  error?: string;
}

class DriverManagementAPI {
  private getAuthToken(): string | null {
    return localStorage.getItem('token');
  }

  private getHeaders() {
    const token = this.getAuthToken();
    return {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` })
    };
  }

  private getFormDataHeaders() {
    const token = this.getAuthToken();
    return {
      'Accept': 'application/json',
      ...(token && { 'Authorization': `Bearer ${token}` })
    };
  }

  // Request OTP for mobile number
  async requestOtp(mobileNumber: string, purpose: 'register' = 'register'): Promise<ApiResponse<OtpResponse>> {
    try {
      console.log('Requesting OTP for:', mobileNumber);
      
      const payload: OtpRequestPayload = {
        mobile_number: mobileNumber,
        purpose
      };

      console.log('OTP Request Payload:', payload);
      console.log('Request URL:', `${BASE_URL}/api/auth/request-otp`);

      const response = await axios.post(
        `${BASE_URL}/api/auth/request-otp`,
        payload,
        {
          headers: this.getHeaders(),
          timeout: 10000
        }
      );

      console.log('OTP Response:', response.data);

      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('OTP Request Error:', error);
      return handleApiError(error);
    }
  }

  // Verify OTP and get otp_log_id
  async verifyOtp(
    mobileNumber: string, 
    otpCode: string, 
    purpose: 'register' = 'register',
    clientIp?: string
  ): Promise<ApiResponse<OtpResponse>> {
    try {
      console.log('Verifying OTP:', { mobileNumber, otpCode });
      
      const payload: OtpVerifyPayload = {
        mobile_number: mobileNumber,
        otp_code: otpCode,
        purpose
      };

      const headers: any = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        ...(clientIp && { 'x-client-ip': clientIp })
      };

      const token = this.getAuthToken();
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      console.log('Verify OTP Headers:', headers);
      console.log('Verify OTP Payload:', payload);

      const response = await axios.post(
        `${BASE_URL}/api/auth/verify-otp`,
        payload,
        {
          headers,
          timeout: 10000
        }
      );

      console.log('Verify OTP Response:', response.data);

      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Verify OTP Error:', error);
      return handleApiError(error);
    }
  }

  // Get list of drivers for the partner
  async getDrivers(): Promise<ApiResponse<Driver[]>> {
    try {
      const token = this.getAuthToken();
      if (!token) {
        console.error('No authentication token found');
        return {
          success: false,
          error: 'Authentication required',
          message: 'Please login first'
        };
      }

      console.log('Getting drivers with token:', token.substring(0, 20) + '...');
      console.log('Request URL:', `${BASE_URL}/api/profile/drivers`);

      const response = await axios.get(
        `${BASE_URL}/api/profile/drivers`,
        {
          headers: this.getHeaders(),
          timeout: 10000
        }
      );

      console.log('Drivers Response:', response.data);

      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Get Drivers Error:', error);
      return handleApiError(error);
    }
  }

  // Create new driver
  async createDriver(formData: DriverFormData): Promise<DriverCreateResponse> {
    try {
      const token = this.getAuthToken();
      if (!token) {
        console.error('No authentication token found for create driver');
        return {
          success: false,
          error: 'Authentication required',
          message: 'Please login first'
        };
      }

      console.log('Creating driver with data:', {
        first_name: formData.first_name,
        last_name: formData.last_name,
        mobile_number: formData.mobile_number,
        mobile_otp_log_id: formData.mobile_otp_log_id
      });

      // Create FormData object
      const multipartData = new FormData();
      
      // Append text fields
      multipartData.append('first_name', formData.first_name);
      multipartData.append('last_name', formData.last_name);
      multipartData.append('mobile_number', formData.mobile_number);
      multipartData.append('mobile_otp_log_id', formData.mobile_otp_log_id.toString());
      multipartData.append('date_of_birth', formData.date_of_birth);
      multipartData.append('driving_licence_number', formData.driving_licence_number);
      
      // Append optional fields if they exist
      if (formData.email_address) {
        multipartData.append('email_address', formData.email_address);
        if (formData.email_otp_log_id) {
          multipartData.append('email_otp_log_id', formData.email_otp_log_id.toString());
        }
      }
      
      if (formData.gender) {
        multipartData.append('gender', formData.gender);
      }
      
      if (formData.location) {
        multipartData.append('location', formData.location);
      }
      
      if (formData.aadhaar_number) {
        multipartData.append('aadhaar_number', formData.aadhaar_number);
      }
      
      // Append files
      if (formData.profile_image) {
        console.log('Adding profile image:', formData.profile_image.name, formData.profile_image.size);
        multipartData.append('profile_image', formData.profile_image);
      }
      
      if (formData.driving_licence_front) {
        console.log('Adding DL front:', formData.driving_licence_front.name, formData.driving_licence_front.size);
        multipartData.append('driving_licence_front', formData.driving_licence_front);
      }
      
      if (formData.driving_licence_back) {
        console.log('Adding DL back:', formData.driving_licence_back.name, formData.driving_licence_back.size);
        multipartData.append('driving_licence_back', formData.driving_licence_back);
      }
      
      if (formData.aadhaar_front) {
        console.log('Adding Aadhaar front:', formData.aadhaar_front.name, formData.aadhaar_front.size);
        multipartData.append('aadhaar_front', formData.aadhaar_front);
      }

      // Log FormData contents
      console.log('FormData entries:');
      for (const pair of multipartData.entries()) {
        console.log(pair[0] + ': ', pair[1]);
      }

      const response = await axios.post(
        `${BASE_URL}/api/profile/drivers`,
        multipartData,
        {
          headers: this.getFormDataHeaders(),
          timeout: 30000 // Increased timeout for file uploads
        }
      );

      console.log('Create Driver Response:', response.data);

      return {
        success: true,
        data: response.data
      };
    } catch (error: any) {
      console.error('Create Driver Error:', error);
      console.error('Error response:', error.response?.data);
      return handleApiError(error);
    }
  }

  // Helper function to convert data URL to File object
  dataUrlToFile(dataUrl: string, filename: string): File | null {
    try {
      const arr = dataUrl.split(',');
      if (arr.length < 2) {
        console.error('Invalid data URL format');
        return null;
      }
      
      const mimeMatch = arr[0].match(/:(.*?);/);
      if (!mimeMatch) {
        console.error('Could not extract MIME type from data URL');
        return null;
      }
      
      const mime = mimeMatch[1];
      const bstr = atob(arr[1]);
      let n = bstr.length;
      const u8arr = new Uint8Array(n);
      
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      
      const file = new File([u8arr], filename, { type: mime });
      console.log('Created file from data URL:', filename, file.size, 'bytes');
      return file;
    } catch (error) {
      console.error('Error converting data URL to file:', error);
      return null;
    }
  }
}

export const driverManagementAPI = new DriverManagementAPI();