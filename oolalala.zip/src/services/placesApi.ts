export interface Place {
  id: string;
  displayName: {
    text: string;
  };
  formattedAddress: string;
  location?: {
    latitude: number;
    longitude: number;
  };
}

const API_KEY = 'AIzaSyCsWQJdiuPGmabvpX-_4FhyC9C5GKu3TLk';

// Autocomplete API
export const autocompletePlaces = async (input: string): Promise<Place[]> => {
  try {
    const response = await fetch('https://places.googleapis.com/v1/places:autocomplete', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': API_KEY,
        'X-Goog-FieldMask': 'suggestions.placePrediction'
      },
      body: JSON.stringify({
        input,
        includedRegionCodes: ['IN'], // India only
        locationBias: {
          circle: {
            center: {
              latitude: 11.1271, // Tamil Nadu center
              longitude: 78.6569
            },
            radius: 50000.0 // Fixed: 50km radius (max allowed)
          }
        }
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Autocomplete API error:', errorText);
      throw new Error(`Autocomplete API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.suggestions && data.suggestions.length > 0) {
      // Fetch details for each suggestion
      const places = await Promise.all(
        data.suggestions.slice(0, 5).map(async (suggestion: any) => {
          try {
            if (suggestion.placePrediction?.placeId) {
              return await getPlaceDetails(suggestion.placePrediction.placeId);
            }
            return null;
          } catch (error) {
            console.error('Error fetching place details:', error);
            return null;
          }
        })
      );
      
      return places.filter((place): place is Place => place !== null);
    }
    
    return [];
  } catch (error) {
    console.error('Error in autocompletePlaces:', error);
    throw error;
  }
};

// Search Text API for intermediate cities
export const searchTextPlaces = async (input: string): Promise<Place[]> => {
  try {
    const response = await fetch('https://places.googleapis.com/v1/places:searchText', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': API_KEY,
        'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.location'
      },
      body: JSON.stringify({
        textQuery: input,
        languageCode: 'en',
        regionCode: 'IN',
        rankPreference: 'DISTANCE'
      }),
    });

    if (!response.ok) {
      throw new Error(`Search Text API error: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.places && data.places.length > 0) {
      return data.places.slice(0, 5).map((place: any) => ({
        id: place.id,
        displayName: place.displayName,
        formattedAddress: place.formattedAddress,
        location: place.location
      }));
    }
    
    return [];
  } catch (error) {
    console.error('Error in searchTextPlaces:', error);
    throw error;
  }
};

const getPlaceDetails = async (placeId: string): Promise<Place> => {
  const response = await fetch(`https://places.googleapis.com/v1/places/${placeId}`, {
    method: 'GET',
    headers: {
      'X-Goog-Api-Key': API_KEY,
      'X-Goog-FieldMask': 'id,displayName,formattedAddress,location'
    }
  });

  if (!response.ok) {
    throw new Error(`Place details error: ${response.status}`);
  }

  const data = await response.json();
  return {
    id: data.id,
    displayName: data.displayName,
    formattedAddress: data.formattedAddress,
    location: data.location
  };
};