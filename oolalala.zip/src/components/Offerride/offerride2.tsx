import React, { useState, useEffect, useRef } from 'react';
import { CircleArrowRight, RefreshCw, Plus, MapPin, ArrowLeft } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import Navbar from '../layout/Navbar';
import { computeRoutes } from '../../services/routesApi';
import { searchTextPlaces } from '../../services/placesApi';
import { RouteOption, Location } from '../../types';

const OfferRide2: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rideData = location.state;

  const [selectedRoute, setSelectedRoute] = useState<number>(1);
  const [routes, setRoutes] = useState<RouteOption[]>([]);
  const [stops, setStops] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRecalculating, setIsRecalculating] = useState(false);
  const [mapUrl, setMapUrl] = useState('');
  const [mapKey, setMapKey] = useState(Date.now()); // Force map refresh
  
  const mapContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!rideData?.pickup || !rideData?.drop) {
      navigate('/offer-ride1');
      return;
    }

    loadRoutes();
  }, [rideData, stops, navigate]);

  const loadRoutes = async () => {
    setIsLoading(true);
    try {
      const results = await computeRoutes(
        rideData.pickup,
        rideData.drop,
        stops.map(stop => ({ lat: stop.lat, lng: stop.lng })),
        false // Don't avoid tolls for initial calculation
      );

      if (results.routes && results.routes.length > 0) {
        const routeOptions: RouteOption[] = results.routes.map((route, index) => {
          const durationSeconds = parseDurationToSeconds(route.duration);
          return {
            id: index + 1,
            duration: formatDuration(route.duration),
            durationSeconds,
            distance: `${(route.distanceMeters / 1000).toFixed(1)} km`,
            distanceMeters: route.distanceMeters,
            hasTolls: !!route.travelAdvisory?.tollInfo?.estimatedPrice,
            polyline: route.polyline?.encodedPolyline || '',
            legs: route.legs || [],
          };
        });

        setRoutes(routeOptions);
        
        // Update map with first route by default
        if (routeOptions[0]) {
          updateMapUrl(routeOptions[0]);
        }
      }
    } catch (error) {
      console.error('Error loading routes:', error);
      // Fallback to basic Google Maps embed
      const fallbackUrl = `https://www.google.com/maps/embed/v1/directions?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&origin=${rideData.pickup.lat},${rideData.pickup.lng}&destination=${rideData.drop.lat},${rideData.drop.lng}&mode=driving`;
      setMapUrl(fallbackUrl);
    } finally {
      setIsLoading(false);
    }
  };

  const updateMapUrl = (route: RouteOption) => {
    if (!route || !rideData) return;

    const origin = `${rideData.pickup.lat},${rideData.pickup.lng}`;
    const destination = `${rideData.drop.lat},${rideData.drop.lng}`;
    
    let url = `https://www.google.com/maps/embed/v1/directions?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&origin=${origin}&destination=${destination}&mode=driving`;
    
    if (stops.length > 0) {
      const waypoints = stops.map(stop => `${stop.lat},${stop.lng}`).join('|');
      url += `&waypoints=${waypoints}`;
    }

    // Add polyline if available (note: Google Maps embed doesn't support custom polylines directly)
    // For custom polylines, you'd need Google Maps JavaScript API
    setMapUrl(url);
    setMapKey(Date.now()); // Force iframe reload
  };

  const formatDuration = (duration: string): string => {
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    if (!match) return duration;

    const hours = match[1] ? parseInt(match[1]) : 0;
    const minutes = match[2] ? parseInt(match[2]) : 0;

    if (hours > 0) {
      return `${hours}h ${minutes}min`;
    }
    return `${minutes} min`;
  };

  const parseDurationToSeconds = (duration: string): number => {
    const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    if (!match) return 0;

    const hours = match[1] ? parseInt(match[1]) * 3600 : 0;
    const minutes = match[2] ? parseInt(match[2]) * 60 : 0;
    const seconds = match[3] ? parseInt(match[3]) : 0;

    return hours + minutes + seconds;
  };

  const addStop = async () => {
    // In real implementation, you would get coordinates from map click
    // For now, we'll add a stop at midpoint
    const midLat = (rideData.pickup.lat + rideData.drop.lat) / 2;
    const midLng = (rideData.pickup.lng + rideData.drop.lng) / 2;
    
    try {
      // Search for nearest place at this location
      const searchQuery = `place near ${midLat},${midLng}`;
      const places = await searchTextPlaces(searchQuery);
      
      if (places.length > 0) {
        const place = places[0];
        const newStop: Location = {
          lat: place.location?.latitude || midLat,
          lng: place.location?.longitude || midLng,
          address: place.displayName.text,
          placeId: place.id,
        };
        
        setStops([...stops, newStop]);
        setIsRecalculating(true);
        
        // Recalculate routes with new stop
        setTimeout(() => {
          setIsRecalculating(false);
        }, 1000);
      }
    } catch (error) {
      console.error('Error adding stop:', error);
      // Add stop with coordinates only
      const newStop: Location = {
        lat: midLat,
        lng: midLng,
        address: `Stop ${stops.length + 1}`,
        placeId: `stop-${Date.now()}`,
      };
      setStops([...stops, newStop]);
    }
  };

  const removeStop = (index: number) => {
    const newStops = stops.filter((_, i) => i !== index);
    setStops(newStops);
  };

  const handleRouteSelect = (routeId: number) => {
    setSelectedRoute(routeId);
    const selected = routes.find(r => r.id === routeId);
    if (selected) {
      updateMapUrl(selected);
    }
  };

  const handleNext = () => {
    const selectedRouteData = routes.find(r => r.id === selectedRoute);
    if (!selectedRouteData) return;

    const totalDistanceKm = selectedRouteData.distanceMeters / 1000;
    const totalDuration = selectedRouteData.durationSeconds;
    const farePerKm = parseFloat(rideData.settings?.fare_per_km_car || '12');
    const calculatedPrice = Math.round(totalDistanceKm * farePerKm * rideData.seats);

    const updatedRideData = {
      ...rideData,
      stops,
      selectedRoute: selectedRouteData,
      totalDistance: totalDistanceKm,
      totalDuration,
      calculatedPrice,
    };

    navigate('/offer-ride3', { state: updatedRideData });
  };

  const recalculateRoute = async (avoidTolls: boolean) => {
    setIsRecalculating(true);
    try {
      const results = await computeRoutes(
        rideData.pickup,
        rideData.drop,
        stops.map(stop => ({ lat: stop.lat, lng: stop.lng })),
        avoidTolls
      );

      if (results.routes && results.routes.length > 0) {
        const routeOptions: RouteOption[] = results.routes.map((route, index) => {
          const durationSeconds = parseDurationToSeconds(route.duration);
          return {
            id: index + 1,
            duration: formatDuration(route.duration),
            durationSeconds,
            distance: `${(route.distanceMeters / 1000).toFixed(1)} km`,
            distanceMeters: route.distanceMeters,
            hasTolls: !!route.travelAdvisory?.tollInfo?.estimatedPrice,
            polyline: route.polyline?.encodedPolyline || '',
            legs: route.legs || [],
          };
        });

        setRoutes(routeOptions);
        if (routeOptions[0]) {
          updateMapUrl(routeOptions[0]);
          setSelectedRoute(1);
        }
      }
    } catch (error) {
      console.error('Error recalculating route:', error);
    } finally {
      setIsRecalculating(false);
    }
  };

  return (
    <div className="h-screen overflow-hidden bg-background flex flex-col">
      <Navbar />

      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="fixed top-20 left-4 z-20 p-2 hover:bg-accent rounded-full transition-colors"
        aria-label="Go back"
      >
        <ArrowLeft size={20} className="text-foreground" />
      </button>

      <div className="flex-1 pt-16 overflow-hidden">
        <div className="h-full max-w-6xl mx-auto px-4 py-4 flex flex-col">
          {/* Header */}
          <div className="mb-4 flex-shrink-0">
            <h1 className="text-2xl font-bold text-foreground">Choose Route</h1>
            <p className="text-sm text-muted-foreground">Select the best route for your journey</p>
          </div>

          {/* Content Grid */}
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-0 pb-20">
            {/* Left - Stops & Route Options */}
            <div className="space-y-4 overflow-y-auto">
              {/* Stops Section */}
              <div className="bg-card rounded-xl p-4 border border-border">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-foreground">Add Stops ({stops.length})</h3>
                  <button
                    onClick={addStop}
                    disabled={isRecalculating}
                    className="p-2 bg-primary text-primary-foreground rounded-full hover:bg-primary/90 transition-colors disabled:opacity-50"
                  >
                    <Plus size={18} />
                  </button>
                </div>
                
                <div className="space-y-2">
                  {stops.map((stop, index) => (
                    <div
                      key={stop.placeId}
                      className="flex items-center justify-between bg-accent/50 p-3 rounded-lg"
                    >
                      <div className="flex items-center gap-2">
                        <MapPin size={14} className="text-primary" />
                        <div>
                          <span className="text-sm text-foreground">{stop.address}</span>
                          <div className="text-xs text-muted-foreground">
                            {stop.lat.toFixed(4)}, {stop.lng.toFixed(4)}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => removeStop(index)}
                        className="text-red-500 hover:text-red-700 text-lg"
                      >
                        ×
                      </button>
                    </div>
                  ))}
                  {stops.length === 0 && (
                    <div className="text-center py-4 text-muted-foreground">
                      No stops added. Click + to add a stop.
                    </div>
                  )}
                </div>
              </div>

              {/* Route Options */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium text-foreground">Available Routes</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => recalculateRoute(false)}
                      disabled={isRecalculating}
                      className="px-3 py-1 text-xs bg-primary/10 text-primary rounded-md hover:bg-primary/20"
                    >
                      Fastest
                    </button>
                    <button
                      onClick={() => recalculateRoute(true)}
                      disabled={isRecalculating}
                      className="px-3 py-1 text-xs bg-primary/10 text-primary rounded-md hover:bg-primary/20"
                    >
                      No Tolls
                    </button>
                  </div>
                </div>

                {isLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                    <p className="text-foreground">Loading routes...</p>
                  </div>
                ) : routes.length > 0 ? (
                  routes.map((route) => (
                    <div
                      key={route.id}
                      onClick={() => handleRouteSelect(route.id)}
                      className={`bg-card rounded-xl p-4 border cursor-pointer transition-all ${
                        selectedRoute === route.id
                          ? 'border-primary ring-1 ring-primary'
                          : 'border-border hover:border-primary/50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          {/* Radio */}
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                              selectedRoute === route.id ? 'border-primary' : 'border-muted-foreground/40'
                            }`}
                          >
                            {selectedRoute === route.id && (
                              <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                            )}
                          </div>

                          {/* Route Info */}
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-lg font-semibold text-foreground">{route.duration}</span>
                              <span
                                className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                                  route.hasTolls
                                    ? 'bg-primary/10 text-primary'
                                    : 'bg-muted text-muted-foreground'
                                }`}
                              >
                                {route.hasTolls ? 'With tolls' : 'No tolls'}
                              </span>
                            </div>
                            <span className="text-sm text-muted-foreground">{route.distance}</span>
                          </div>
                        </div>

                        {/* Refresh Icon */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            // Refresh this route
                          }}
                          className="p-2 text-primary hover:bg-primary/10 rounded-lg transition-colors"
                        >
                          <RefreshCw className="w-5 h-5" />
                        </button>
                      </div>

                      {/* Segment Details */}
                      {route.legs.length > 0 && (
                        <div className="mt-3 pl-9 space-y-2">
                          {route.legs.map((leg, index) => (
                            <div key={index} className="flex justify-between text-sm">
                              <span className="text-muted-foreground">Segment {index + 1}:</span>
                              <span className="font-medium text-foreground">
                                {(leg.distanceMeters / 1000).toFixed(1)} km • {formatDuration(leg.duration)}
                              </span>
                            </div>
                          ))}
                          {/* Total */}
                          <div className="flex justify-between text-sm font-medium pt-2 border-t">
                            <span className="text-foreground">Total:</span>
                            <span className="text-primary">{route.distance} • {route.duration}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    No routes found. Please check your locations.
                  </div>
                )}
                
                {/* Recalculating Indicator */}
                {isRecalculating && (
                  <div className="text-center py-4 text-sm text-muted-foreground">
                    Recalculating route with stops...
                  </div>
                )}
              </div>
            </div>

            {/* Right - Google Maps */}
            <div className="relative h-full rounded-xl overflow-hidden border border-border bg-muted" ref={mapContainerRef}>
              {mapUrl ? (
                <iframe
                  key={mapKey}
                  src={mapUrl}
                  className="w-full h-full"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Route Map"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                    <p className="text-muted-foreground">Loading map...</p>
                  </div>
                </div>
              )}
              
              {/* Location Label */}
              <div className="absolute top-3 left-3 bg-card/95 backdrop-blur-sm px-3 py-1.5 rounded-lg text-sm font-medium text-foreground border border-border shadow-sm">
                <div className="flex items-center gap-1">
                  <MapPin size={12} className="text-primary" />
                  <span>{rideData.pickup.address.split(',')[0]} → {rideData.drop.address.split(',')[0]}</span>
                </div>
                {stops.length > 0 && (
                  <div className="text-xs text-muted-foreground mt-1">
                    +{stops.length} stop{stops.length > 1 ? 's' : ''}
                  </div>
                )}
              </div>
              
              {/* Add Stop Button on Map */}
              <button
                onClick={addStop}
                disabled={isRecalculating}
                className="absolute bottom-3 right-3 bg-primary text-primary-foreground px-4 py-2 rounded-lg shadow-lg hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                <div className="flex items-center gap-2">
                  <Plus size={16} />
                  <span>Add Stop</span>
                </div>
              </button>
            </div>
          </div>

          {/* FLOATING CONTINUE BUTTON */}
          <div className="fixed bottom-6 right-6 z-10">
            <button
              onClick={handleNext}
              disabled={isLoading || routes.length === 0 || isRecalculating}
              className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-105 ${
                !isLoading && routes.length > 0 && !isRecalculating
                  ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
              aria-label="Continue"
            >
              <CircleArrowRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferRide2;