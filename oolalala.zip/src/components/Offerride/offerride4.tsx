import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Navbar from "../layout/Navbar";

export default function OfferRide4() {
  const navigate = useNavigate();

  const handlePublish = () => {
    console.log("Ride published!");
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <Navbar />
      
      {/* Main content - fixed top spacing to avoid overlap */}
      <div className="pt-20 px-4 flex items-center justify-center min-h-[calc(100vh-80px)]">
        <div className="w-full max-w-md bg-card rounded-2xl px-8 py-8 text-center border border-border shadow-lg">
          {/* Header */}
          <div className="flex items-center mb-8">
            <button
              onClick={() => navigate(-1)}
              className="p-2 hover:bg-accent rounded-full transition-colors"
              aria-label="Go back"
            >
              <ArrowLeft size={20} className="text-foreground" />
            </button>
            <h1 className="flex-1 text-center text-[15px] font-semibold text-foreground pr-10">
              Review My Offer
            </h1>
          </div>

          {/* Route */}
          <h2 className="text-xl font-bold text-foreground mb-1">
            Chennai → Coimbatore
          </h2>
          <p className="text-sm text-muted-foreground mb-8">
            485 km · 7h 30min
          </p>

          {/* Date / Time / Seats */}
          <div className="flex justify-between text-sm text-muted-foreground mb-8 px-4">
            <div className="flex flex-col items-center">
              <span className="font-medium text-foreground">12 Aug</span>
              <span className="text-xs mt-1">Date</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="font-medium text-foreground">08:00 AM</span>
              <span className="text-xs mt-1">Time</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="font-medium text-foreground">3 Seats</span>
              <span className="text-xs mt-1">Seats</span>
            </div>
          </div>

          {/* Price */}
          <div className="mb-8">
            <span className="text-4xl font-bold text-primary">₹650</span>
            <span className="text-xl text-primary ml-2">per seat</span>
          </div>

          {/* Vehicle & Driver */}
          <div className="text-sm text-muted-foreground space-y-2 mb-8">
            <div className="flex justify-between items-center py-1">
              <span>Vehicle:</span>
              <span className="font-medium text-foreground">TN 02 FH 7483</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span>Driver:</span>
              <span className="font-medium text-foreground">Ramesh K</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span>Contact:</span>
              <span className="font-medium text-foreground">+91 8978096745</span>
            </div>
            <div className="flex justify-between items-center py-1">
              <span>Preferences:</span>
              <span className="font-medium text-primary">Kids only</span>
            </div>
          </div>

          {/* Publish Button */}
          <button 
            onClick={handlePublish}
            className="w-full py-3.5 rounded-full bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 transition-colors"
          >
            Publish Ride
          </button>
        </div>
      </div>
    </div>
  );
}