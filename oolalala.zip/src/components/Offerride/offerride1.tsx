import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  MapPin,
  Send,
  Calendar,
  Clock,
  Users,
  Minus,
  Plus,
  CircleArrowRight,
  X,
  ArrowLeft,
} from 'lucide-react';
import Navbar from '../layout/Navbar';
import { useNavigate } from 'react-router-dom';
import { fetchSettings, fetchPreferences } from '../../services/settingsApi';
import { autocompletePlaces, Place } from '../../services/placesApi';
import { Location } from '../../types';

const OfferRide1: React.FC = () => {
  const navigate = useNavigate();
  
  // Form state
  const [pickupLocation, setPickupLocation] = useState('');
  const [dropLocation, setDropLocation] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('08:30');
  const [timeFormat, setTimeFormat] = useState<'AM' | 'PM'>('AM');
  const [seats, setSeats] = useState(2);
  const [preferences, setPreferences] = useState<string[]>([]);
  const [selectedPreferences, setSelectedPreferences] = useState<string[]>([]);
  
  // API data
  const [settings, setSettings] = useState<any>(null);
  
  // Autocomplete
  const [pickupSuggestions, setPickupSuggestions] = useState<Place[]>([]);
  const [dropSuggestions, setDropSuggestions] = useState<Place[]>([]);
  const [showPickupSuggestions, setShowPickupSuggestions] = useState(false);
  const [showDropSuggestions, setShowDropSuggestions] = useState(false);
  const [selectedPickup, setSelectedPickup] = useState<Location | null>(null);
  const [selectedDrop, setSelectedDrop] = useState<Location | null>(null);
  
  // Loading states
  const [loadingSettings, setLoadingSettings] = useState(true);
  const [loadingPreferences, setLoadingPreferences] = useState(true);
  
  const pickupRef = useRef<HTMLDivElement>(null);
  const dropRef = useRef<HTMLDivElement>(null);
  const debounceTimeout = useRef<NodeJS.Timeout>();

  // Initialize
  useEffect(() => {
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    setDate(formattedDate);
    
    loadSettings();
    loadPreferences();
  }, []);

  const loadSettings = async () => {
    try {
      const settingsData = await fetchSettings();
      setSettings(settingsData);
    } catch (error) {
      console.error('Failed to load settings:', error);
    } finally {
      setLoadingSettings(false);
    }
  };

  const loadPreferences = async () => {
    try {
      const prefs = await fetchPreferences();
      setPreferences(prefs);
    } catch (error) {
      console.error('Failed to load preferences:', error);
      // Fallback preferences
      setPreferences(['Ladies only', 'Kids Only', 'Senior Citizens', 'Students only', 'Professionals only']);
    } finally {
      setLoadingPreferences(false);
    }
  };

  // Debounced search for pickup
  const searchPickupPlaces = useCallback((query: string) => {
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    if (query.length < 2) {
      setPickupSuggestions([]);
      return;
    }

    debounceTimeout.current = setTimeout(async () => {
      try {
        const results = await autocompletePlaces(query);
        setPickupSuggestions(results);
        setShowPickupSuggestions(true);
      } catch (error) {
        console.error('Error searching pickup places:', error);
      }
    }, 300);
  }, []);

  // Debounced search for drop
  const searchDropPlaces = useCallback((query: string) => {
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    if (query.length < 2) {
      setDropSuggestions([]);
      return;
    }

    debounceTimeout.current = setTimeout(async () => {
      try {
        const results = await autocompletePlaces(query);
        setDropSuggestions(results);
        setShowDropSuggestions(true);
      } catch (error) {
        console.error('Error searching drop places:', error);
      }
    }, 300);
  }, []);

  const handlePickupSelect = (place: Place) => {
    const location: Location = {
      lat: place.location?.latitude || 0,
      lng: place.location?.longitude || 0,
      address: place.displayName.text,
      placeId: place.id,
    };
    setPickupLocation(place.displayName.text);
    setSelectedPickup(location);
    setShowPickupSuggestions(false);
  };

  const handleDropSelect = (place: Place) => {
    const location: Location = {
      lat: place.location?.latitude || 0,
      lng: place.location?.longitude || 0,
      address: place.displayName.text,
      placeId: place.id,
    };
    setDropLocation(place.displayName.text);
    setSelectedDrop(location);
    setShowDropSuggestions(false);
  };

  const togglePreference = (pref: string) => {
    setSelectedPreferences(prev =>
      prev.includes(pref)
        ? prev.filter(p => p !== pref)
        : [...prev, pref]
    );
  };

  const handleContinue = () => {
    if (!selectedPickup || !selectedDrop) {
      alert('Please select valid pickup and drop locations');
      return;
    }

    if (!selectedPickup.lat || !selectedPickup.lng || !selectedDrop.lat || !selectedDrop.lng) {
      alert('Location coordinates not available. Please select from suggestions.');
      return;
    }

    const rideData = {
      pickup: selectedPickup,
      drop: selectedDrop,
      stops: [],
      date,
      time,
      timeFormat,
      seats,
      preferences: selectedPreferences,
      selectedRoute: null,
      totalDistance: 0,
      totalDuration: 0,
      settings,
    };

    navigate('/offer-ride2', { state: rideData });
  };

  // Close suggestions on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (pickupRef.current && !pickupRef.current.contains(event.target as Node)) {
        setShowPickupSuggestions(false);
      }
      if (dropRef.current && !dropRef.current.contains(event.target as Node)) {
        setShowDropSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="h-screen overflow-hidden bg-background flex flex-col">
      <Navbar />

      {/* Back Button - Fixed Top Left */}
      <button
        onClick={() => navigate(-1)}
        className="fixed top-20 left-4 z-20 p-2 hover:bg-accent rounded-full transition-colors"
        aria-label="Go back"
      >
        <ArrowLeft size={20} className="text-foreground" />
      </button>

      {/* MAIN AREA */}
      <div className="flex-1 pt-16 overflow-hidden">
        <div className="h-full max-w-6xl mx-auto px-4 py-4 flex flex-col">
          {/* HEADER */}
          <div className="mb-6 flex-shrink-0">
            <h1 className="text-2xl font-bold text-foreground">
              Offer a Ride
            </h1>
            <p className="text-sm text-muted-foreground">
              Fill the details to create your ride
            </p>
          </div>

          {/* CONTENT - Single row layout, no scroll */}
          <div className="flex-1 flex flex-col gap-6">
            {/* PICKUP & DROP IN SINGLE ROW */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* PICKUP LOCATION */}
              <div className="relative" ref={pickupRef}>
                <div className="bg-card rounded-xl p-4 border border-border">
                  <div className="flex items-center gap-3">
                    <MapPin className="text-primary" size={18} />
                    <input
                      value={pickupLocation}
                      onChange={(e) => {
                        setPickupLocation(e.target.value);
                        searchPickupPlaces(e.target.value);
                      }}
                      onFocus={() => setShowPickupSuggestions(true)}
                      placeholder="Enter pickup location"
                      className="w-full font-semibold outline-none bg-transparent placeholder:text-muted-foreground"
                    />
                    {pickupLocation && (
                      <button
                        onClick={() => {
                          setPickupLocation('');
                          setSelectedPickup(null);
                          setPickupSuggestions([]);
                        }}
                        className="p-1 hover:bg-muted rounded-full"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Pickup Suggestions */}
                {showPickupSuggestions && pickupSuggestions.length > 0 && (
                  <div className="absolute z-10 mt-1 w-full bg-card border border-border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {pickupSuggestions.map((place) => (
                      <div
                        key={place.id}
                        onClick={() => handlePickupSelect(place)}
                        className="px-4 py-3 hover:bg-accent cursor-pointer border-b last:border-b-0"
                      >
                        <div className="font-medium text-foreground">{place.displayName.text}</div>
                        <div className="text-xs text-muted-foreground">
                          {place.formattedAddress}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* DROP LOCATION */}
              <div className="relative" ref={dropRef}>
                <div className="bg-card rounded-xl p-4 border border-border">
                  <div className="flex items-center gap-3">
                    <Send className="text-primary rotate-45" size={18} />
                    <input
                      value={dropLocation}
                      onChange={(e) => {
                        setDropLocation(e.target.value);
                        searchDropPlaces(e.target.value);
                      }}
                      onFocus={() => setShowDropSuggestions(true)}
                      placeholder="Enter drop location"
                      className="w-full font-semibold outline-none bg-transparent placeholder:text-muted-foreground"
                    />
                    {dropLocation && (
                      <button
                        onClick={() => {
                          setDropLocation('');
                          setSelectedDrop(null);
                          setDropSuggestions([]);
                        }}
                        className="p-1 hover:bg-muted rounded-full"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                </div>
                
                {/* Drop Suggestions */}
                {showDropSuggestions && dropSuggestions.length > 0 && (
                  <div className="absolute z-10 mt-1 w-full bg-card border border-border rounded-lg shadow-lg max-h-60 overflow-y-auto">
                    {dropSuggestions.map((place) => (
                      <div
                        key={place.id}
                        onClick={() => handleDropSelect(place)}
                        className="px-4 py-3 hover:bg-accent cursor-pointer border-b last:border-b-0"
                      >
                        <div className="font-medium text-foreground">{place.displayName.text}</div>
                        <div className="text-xs text-muted-foreground">
                          {place.formattedAddress}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* DATE & TIME - Single row */}
            <div className="bg-card rounded-xl p-4 border border-border grid md:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Calendar className="text-primary" size={18} />
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full font-semibold outline-none bg-transparent"
                />
              </div>

              <div className="flex items-center gap-3">
                <Clock className="text-primary" size={18} />
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="text-lg font-bold w-28 outline-none bg-transparent"
                />
                <div className="flex border rounded-md overflow-hidden">
                  <button
                    onClick={() => setTimeFormat('AM')}
                    className={`px-4 py-1 text-sm font-medium ${
                      timeFormat === 'AM'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-transparent'
                    }`}
                  >
                    AM
                  </button>
                  <button
                    onClick={() => setTimeFormat('PM')}
                    className={`px-4 py-1 text-sm font-medium ${
                      timeFormat === 'PM'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-transparent'
                    }`}
                  >
                    PM
                  </button>
                </div>
              </div>
            </div>

            {/* SEATS */}
            <div className="bg-card rounded-xl p-4 border border-border flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Users className="text-primary" size={18} />
                <span className="font-medium text-foreground">
                  Seats available
                </span>
              </div>

              <div className="flex items-center gap-4">
                <button
                  onClick={() => seats > 1 && setSeats(seats - 1)}
                  className="w-10 h-10 border rounded-full flex items-center justify-center hover:bg-accent"
                >
                  <Minus size={16} />
                </button>

                <span className="text-2xl font-bold">{seats}</span>

                <button
                  onClick={() => seats < 8 && setSeats(seats + 1)}
                  className="w-10 h-10 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>

            {/* PREFERENCES */}
            <div className="bg-card rounded-xl p-4 border border-border">
              <p className="text-sm font-medium mb-3 text-foreground">
                Preferences
              </p>
              <div className="flex flex-wrap gap-2">
                {loadingPreferences ? (
                  <div className="text-sm text-muted-foreground">Loading preferences...</div>
                ) : (
                  preferences.map(pref => (
                    <button
                      key={pref}
                      onClick={() => togglePreference(pref)}
                      className={`px-4 py-2 rounded-lg font-medium transition ${
                        selectedPreferences.includes(pref)
                          ? 'bg-primary text-primary-foreground'
                          : 'bg-muted text-muted-foreground hover:bg-muted/80'
                      }`}
                    >
                      {pref}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* FLOATING CONTINUE BUTTON */}
          <div className="fixed bottom-6 right-6 z-10">
            <button
              onClick={handleContinue}
              disabled={!selectedPickup || !selectedDrop || loadingSettings}
              className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all ${
                selectedPickup && selectedDrop && !loadingSettings
                  ? 'bg-primary text-primary-foreground hover:bg-primary/90 hover:scale-105'
                  : 'bg-muted text-muted-foreground cursor-not-allowed'
              }`}
              aria-label="Continue"
            >
              <CircleArrowRight className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OfferRide1;