import React, { useState, useEffect } from 'react';
import { CircleArrowRight, Minus, Plus, ArrowLeft, IndianRupee } from 'lucide-react';
import Navbar from '../layout/Navbar';
import { useNavigate, useLocation } from 'react-router-dom';

const OfferRide3: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const rideData = location.state;

  const [price, setPrice] = useState(650);

  useEffect(() => {
    if (rideData?.calculatedPrice) {
      setPrice(rideData.calculatedPrice);
    }
  }, [rideData]);

  if (!rideData) {
    navigate('/offer-ride1');
    return null;
  }

  const handlePriceChange = (newPrice: number) => {
    if (newPrice >= 50 && newPrice <= 2000) {
      setPrice(newPrice);
    }
  };

  const handleNext = () => {
    const updatedRideData = {
      ...rideData,
      pricePerSeat: price,
    };
    navigate('/offer-ride4', { state: updatedRideData });
  };

  // Calculate price breakdown
  const farePerKm = parseFloat(rideData.settings?.fare_per_km_car || '12');
  const basePrice = rideData.totalDistance * farePerKm;
  const totalWithoutCommission = basePrice * rideData.seats;
  const commission = totalWithoutCommission * (parseFloat(rideData.settings?.platform_commission_percent || '15') / 100);
  const finalPrice = Math.round(totalWithoutCommission - commission);
  const suggestedPrice = finalPrice;

  const formatTime = () => {
    return `${rideData.time} ${rideData.timeFormat}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="fixed top-20 left-4 z-20 p-2 hover:bg-accent rounded-full transition-colors"
        aria-label="Go back"
      >
        <ArrowLeft size={20} className="text-foreground" />
      </button>

      <div className="pt-32 px-4 flex flex-col items-center gap-8 pb-20">
        {/* Main Price Card */}
        <div
          className="w-full max-w-md bg-card rounded-3xl p-8 text-center border border-border"
          style={{
            boxShadow: "0 10px 40px rgba(255, 255, 255, 0.5)",
          }}
        >
          <h2 className="text-xl font-semibold mb-8 text-foreground">
            Price per seat
          </h2>

          {/* Price controller section */}
          <div className="flex items-center justify-center gap-8 mb-8">
            <button
              onClick={() => handlePriceChange(price - 50)}
              disabled={price <= 50}
              className="w-14 h-14 rounded-full border border-primary flex items-center justify-center text-primary disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/5 transition-colors"
            >
              <Minus size={22} />
            </button>

            <div className="flex items-center gap-1 text-4xl font-bold text-primary">
              <IndianRupee size={28} />
              {price}
            </div>

            <button
              onClick={() => handlePriceChange(price + 50)}
              disabled={price >= 2000}
              className="w-14 h-14 rounded-full border border-primary flex items-center justify-center text-primary disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/5 transition-colors"
            >
              <Plus size={22} />
            </button>
          </div>

          <p className="text-sm text-muted-foreground mb-4">
            Set a fair price for one passenger
          </p>

          {/* Suggested Price Info */}
          <div className="text-xs text-muted-foreground bg-accent/30 p-3 rounded-lg">
            <p>Suggested based on distance: <span className="font-medium text-primary">₹{suggestedPrice}</span></p>
            <p className="mt-1">{rideData.totalDistance.toFixed(1)} km × ₹{farePerKm}/km × {rideData.seats} seats</p>
          </div>
        </div>

        {/* Price Breakdown Card */}
        <div className="w-full max-w-md bg-card rounded-2xl p-6 border border-border">
          <h3 className="font-semibold mb-4 text-foreground">Price Breakdown</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Distance</span>
              <span className="font-medium">{rideData.totalDistance.toFixed(1)} km</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Fare per km</span>
              <span className="font-medium">₹{farePerKm}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Base price</span>
              <span className="font-medium">₹{basePrice.toFixed(0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Number of seats</span>
              <span className="font-medium">{rideData.seats}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span className="font-medium">₹{totalWithoutCommission.toFixed(0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Platform fee ({rideData.settings?.platform_commission_percent || '15'}%)</span>
              <span className="font-medium">-₹{commission.toFixed(0)}</span>
            </div>
            <div className="border-t pt-3 flex justify-between font-semibold text-foreground">
              <span>Your earnings per seat</span>
              <span>₹{finalPrice}</span>
            </div>
            <div className="border-t pt-3 flex justify-between font-semibold text-primary text-lg">
              <span>Total earnings ({rideData.seats} seats)</span>
              <span>₹{finalPrice * rideData.seats}</span>
            </div>
          </div>
        </div>

        {/* Trip Summary */}
        <div className="w-full max-w-md bg-card rounded-2xl p-6 border border-border">
          <h3 className="font-semibold mb-4 text-foreground">Trip Summary</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Route</span>
              <span className="font-medium text-right">
                {rideData.pickup.address.split(',')[0]} → {rideData.drop.address.split(',')[0]}
              </span>
            </div>
            {rideData.stops && rideData.stops.length > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stops</span>
                <span className="font-medium">{rideData.stops.length} stop{rideData.stops.length > 1 ? 's' : ''}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-muted-foreground">Date & Time</span>
              <span className="font-medium">{rideData.date} • {formatTime()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Selected Route</span>
              <span className="font-medium">{rideData.selectedRoute?.duration} ({rideData.selectedRoute?.distance})</span>
            </div>
            {rideData.preferences.length > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Preferences</span>
                <span className="font-medium text-primary">{rideData.preferences.join(', ')}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Floating circular arrow button at bottom right */}
      <div className="fixed bottom-6 right-6 z-10">
        <button 
          onClick={handleNext}
          className="w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors hover:scale-105"
          aria-label="Continue to next step"
        >
          <CircleArrowRight className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
};

export default OfferRide3;