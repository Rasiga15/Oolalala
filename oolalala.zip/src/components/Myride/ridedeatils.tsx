// components/Myride/ridedetails.tsx
import { X, Calendar, Clock, Users, User, Car, MapPin, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/seperator";
import { RideDetails as ApiRideDetails, formatDate, formatTime, getStatusDisplayText } from "@/services/myrideapi";

interface RideDetailsProps {
  ride: ApiRideDetails;
  onClose: () => void;
}

export function RideDetails({ ride, onClose }: RideDetailsProps) {
  const totalStopsDistance = ride.stops.reduce((acc, stop) => {
    const dist = stop.distance || 0;
    return acc + dist;
  }, 0);

  const totalFare = ride.fares.reduce((acc, fare) => acc + (fare.amount || 0), 0);
  const displayFare = ride.base_fare || totalFare;

  return (
    <div className="animate-slide-in-right flex h-full flex-col bg-card">
      {/* Header with Close Button */}
      <div className="flex items-start justify-between border-b border-border p-5">
        <div>
          <h2 className="text-xl font-bold text-foreground">
            {ride.start_address} → {ride.end_address}
          </h2>
          <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              <span>{formatDate(ride.travel_datetime)}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="h-4 w-4" />
              <span>{formatTime(ride.travel_datetime)}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Users className="h-4 w-4" />
              <span>{ride.available_seats}/{ride.total_seats} Seats</span>
            </div>
          </div>
          <div className="mt-2 text-sm text-muted-foreground">
            Status: {getStatusDisplayText(ride.ride_status)}
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="h-8 w-8 rounded-full p-0"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5">
        {/* Ride Details */}
        <section className="mb-6">
          <h3 className="text-sm font-semibold text-primary">Ride Details</h3>
          <div className="mt-3 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Ride Type:</span>
              <span className="font-medium text-foreground">
                {ride.is_full_car ? 'Full Car' : 'Shared'}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Instant Confirm:</span>
              <span className="font-medium text-foreground">
                {ride.instant_confirmed ? 'Yes' : 'No'}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Negotiable:</span>
              <span className="font-medium text-foreground">
                {ride.is_negotiable ? 'Yes' : 'No'}
              </span>
            </div>
          </div>
        </section>

        <Separator className="my-4" />

        {/* Vehicle Details */}
        <section className="mb-6">
          <h3 className="text-sm font-semibold text-primary">Vehicle Details</h3>
          {ride.vehicle && (
            <div className="mt-3 space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Car className="h-4 w-4 text-muted-foreground" />
                <span className="font-medium text-foreground">
                  {ride.vehicle.number_plate}
                </span>
              </div>
              {ride.vehicle.model && (
                <div className="text-sm text-muted-foreground">
                  Model: {ride.vehicle.model}
                </div>
              )}
              <div className="text-sm text-muted-foreground">
                Type: {ride.vehicle.vehicle_type}
              </div>
              <div className="text-sm text-muted-foreground">
                Capacity: {ride.vehicle.seating_capacity} seats
              </div>
              <div className="text-sm text-muted-foreground">
                Ownership: {ride.vehicle.ownership_type}
              </div>
            </div>
          )}
        </section>

        <Separator className="my-4" />

        {/* Stops */}
        {ride.stops && ride.stops.length > 0 && (
          <>
            <section className="mb-6">
              <h3 className="text-sm font-semibold text-primary">Stops</h3>
              <div className="mt-3 space-y-3">
                {ride.stops.map((stop, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between text-sm"
                  >
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{stop.location_name || stop.address || `Stop ${index + 1}`}</span>
                    </div>
                    {stop.distance && (
                      <span className="font-medium text-foreground">
                        {stop.distance} km
                      </span>
                    )}
                  </div>
                ))}
                {totalStopsDistance > 0 && (
                  <div className="flex items-center justify-between border-t border-border pt-3 text-sm">
                    <span className="text-muted-foreground">Total Stops Distance</span>
                    <span className="font-medium text-foreground">{totalStopsDistance} km</span>
                  </div>
                )}
              </div>
            </section>
            <Separator className="my-4" />
          </>
        )}

        {/* Fares */}
        {ride.fares && ride.fares.length > 0 && (
          <section className="mb-6">
            <h3 className="text-sm font-semibold text-primary">Fare Breakdown</h3>
            <div className="mt-3 space-y-2">
              {ride.fares.map((fare, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-muted-foreground">
                    {fare.description || `Fare ${index + 1}`}
                  </span>
                  <span className="text-foreground">₹{fare.amount || 0}</span>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>

      {/* Footer - Total Amount */}
      <div className="border-t border-border p-5">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-sm font-semibold text-foreground">
              Total Amount
            </span>
            {ride.total_distance && (
              <div className="text-xs text-muted-foreground">
                Distance: {ride.total_distance} km
              </div>
            )}
          </div>
          <span className="text-2xl font-bold text-primary">
            ₹{displayFare.toLocaleString()}
          </span>
        </div>
      </div>
    </div>
  );
}