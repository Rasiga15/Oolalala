// components/Myride/ridecard.tsx
import { Calendar, Clock, MapPin, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { RideOffer, formatDate, formatTime, getStatusBadgeVariant, getStatusDisplayText } from "@/services/myrideapi";

export interface RideCardProps {
  ride: RideOffer;
  isSelected: boolean;
  onClick: () => void;
}

export function RideCard({ ride, isSelected, onClick }: RideCardProps) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "group cursor-pointer rounded-lg border bg-card p-4 transition-all duration-200 hover:shadow-md",
        isSelected 
          ? "border-primary/30 bg-primary/5 shadow-sm" 
          : "border-border hover:border-primary/20"
      )}
    >
      {/* Route Header */}
      <div className="flex items-start justify-between gap-3">
        <h3 className="text-base font-semibold text-foreground">
          {ride.start_address} → {ride.end_address}
        </h3>
        <Badge variant={getStatusBadgeVariant(ride.ride_status)}>
          {getStatusDisplayText(ride.ride_status)}
        </Badge>
      </div>

      {/* Trip Details */}
      <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5" />
          <span>{formatDate(ride.travel_datetime)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5" />
          <span>{formatTime(ride.travel_datetime)}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <MapPin className="h-3.5 w-3.5" />
          <span>{ride.total_distance ? `${ride.total_distance} km` : 'Distance not set'}</span>
        </div>
      </div>

      {/* Seats & Price */}
      <div className="mt-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="text-sm text-muted-foreground">
            Seats: {ride.available_seats}/{ride.total_seats}
          </div>
          <div className="text-sm text-muted-foreground">
            Vehicle: {ride.vehicle.model || 'N/A'} ({ride.vehicle.number_plate})
          </div>
        </div>
        <span className="text-lg font-bold text-foreground">
          {ride.base_fare ? `₹${ride.base_fare.toLocaleString()}` : 'Price not set'}
        </span>
      </div>
    </div>
  );
}

export type { RideOffer as RideData };