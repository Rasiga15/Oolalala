import React, { useState, useRef, useEffect } from 'react';
import { FiChevronLeft, FiCamera, FiArrowRight, FiMapPin } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';
import { driverManagementAPI } from '@/services/drivermanagementapi';

interface OtpLog {
  id?: number;
  mobile: string;
  verified: boolean;
}

const DriverManagement: React.FC = () => {
  // ================= FORM STATE =================
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [gender, setGender] = useState('');
  const [dob, setDob] = useState('');
  const [mobile, setMobile] = useState('');
  const [location, setLocation] = useState('');
  const [license, setLicense] = useState('');
  const [aadhar, setAadhar] = useState('');

  // ================= OTP =================
  const [showOtp, setShowOtp] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isVerified, setIsVerified] = useState(false);
  const [otpLog, setOtpLog] = useState<OtpLog | null>(null);
  const [isRequestingOtp, setIsRequestingOtp] = useState(false);
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  // ================= CAMERA =================
  const [photo, setPhoto] = useState<string | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // ================= INITIALIZE OTP REFS =================
  useEffect(() => {
    otpRefs.current = otpRefs.current.slice(0, 6);
  }, []);

  // ================= FOCUS FIRST OTP INPUT =================
  useEffect(() => {
    if (showOtp && otpRefs.current[0]) {
      setTimeout(() => {
        otpRefs.current[0]?.focus();
      }, 100);
    }
  }, [showOtp]);

  // ================= OTP HANDLERS =================
  const sendOtp = async () => {
    if (mobile.length !== 10) {
      toast.error('Enter valid 10-digit mobile number');
      return;
    }

    console.log('Sending OTP to:', mobile);
    setIsRequestingOtp(true);
    try {
      const result = await driverManagementAPI.requestOtp(mobile, 'register');
      console.log('Send OTP Result:', result);
      
      if (result.success) {
        // Show OTP section immediately
        setShowOtp(true);
        toast.success('OTP sent successfully to ' + mobile);
      } else {
        toast.error(result.error || 'Failed to send OTP');
      }
    } catch (error) {
      console.error('Error in sendOtp:', error);
      toast.error('Error sending OTP. Please try again.');
    } finally {
      setIsRequestingOtp(false);
    }
  };

  const handleOtpChange = (index: number, value: string) => {
    // Allow only numbers
    if (!/^\d?$/.test(value)) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    
    // Auto focus next input if value is entered
    if (value && index < 5) {
      setTimeout(() => {
        otpRefs.current[index + 1]?.focus();
      }, 10);
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace') {
      if (!otp[index] && index > 0) {
        // Move to previous input on backspace if current is empty
        setTimeout(() => {
          otpRefs.current[index - 1]?.focus();
        }, 10);
      } else if (otp[index]) {
        // Clear current input and stay on same field
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      }
    }
    
    // Auto verify when Enter is pressed
    if (e.key === 'Enter') {
      const fullOtp = otp.join('');
      if (fullOtp.length === 6) {
        verifyOtp();
      }
    }
  };

  const verifyOtp = async () => {
    const otpCode = otp.join('');
    if (otpCode.length !== 6) {
      toast.error('Please enter all 6 digits');
      return;
    }

    console.log('Verifying OTP:', otpCode, 'for mobile:', mobile);
    setIsVerifyingOtp(true);
    try {
      // Get client IP (optional)
      let clientIp = '';
      try {
        const response = await fetch('https://api.ipify.org?format=json');
        const data = await response.json();
        clientIp = data.ip;
        console.log('Client IP:', clientIp);
      } catch (ipError) {
        console.log('Could not fetch IP:', ipError);
      }
      
      const result = await driverManagementAPI.verifyOtp(
        mobile, 
        otpCode, 
        'register',
        clientIp
      );
      
      console.log('Verify OTP Result:', result);
      
      if (result.success && result.data) {
        setIsVerified(true);
        setShowOtp(false);
        setOtpLog({
          id: result.data.otp_log_id,
          mobile: mobile,
          verified: true
        });
        toast.success('Mobile number verified successfully!');
        
        // Clear OTP inputs
        setOtp(['', '', '', '', '', '']);
      } else {
        toast.error(result.error || 'Invalid OTP. Please try again.');
        // Clear OTP for retry
        setOtp(['', '', '', '', '', '']);
        if (otpRefs.current[0]) {
          otpRefs.current[0].focus();
        }
      }
    } catch (error) {
      console.error('Error in verifyOtp:', error);
      toast.error('Error verifying OTP. Please try again.');
    } finally {
      setIsVerifyingOtp(false);
    }
  };

  // ================= CAMERA =================
  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: true 
      });
      streamRef.current = stream;
      setCameraOpen(true);
      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
      }, 100);
    } catch (error) {
      toast.error('Camera access denied. Please allow camera permissions.');
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const ctx = canvasRef.current.getContext('2d');
    if (!ctx) return;
    
    canvasRef.current.width = videoRef.current.videoWidth;
    canvasRef.current.height = videoRef.current.videoHeight;
    ctx.drawImage(videoRef.current, 0, 0);
    const photoData = canvasRef.current.toDataURL('image/jpeg');
    setPhoto(photoData);
    closeCamera();
    toast.success('Photo captured successfully');
  };

  const closeCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
    }
    setCameraOpen(false);
  };

  // ================= SAVE DRIVER =================
  const saveDriver = async () => {
    // Validation
    if (!firstName.trim() || !lastName.trim()) {
      toast.error('First name and last name are required');
      return;
    }
    
    if (!mobile.trim() || mobile.length !== 10) {
      toast.error('Valid mobile number is required');
      return;
    }
    
    if (!isVerified || !otpLog?.id) {
      toast.error('Please verify mobile number first');
      return;
    }
    
    if (!license.trim()) {
      toast.error('Driving license number is required');
      return;
    }
    
    if (!dob) {
      toast.error('Date of birth is required');
      return;
    }

    // Convert photo to File if exists
    let profileImageFile: File | null = null;
    if (photo) {
      profileImageFile = driverManagementAPI.dataUrlToFile(photo, 'profile.jpg');
      if (!profileImageFile) {
        toast.error('Error processing profile photo');
        return;
      }
    }

    // Prepare form data
    const formData: any = {
      first_name: firstName.trim(),
      last_name: lastName.trim(),
      mobile_number: mobile.trim(),
      mobile_otp_log_id: otpLog.id,
      date_of_birth: dob,
      driving_licence_number: license.trim(),
      profile_image: profileImageFile,
      driving_licence_front: null, // You need to implement file upload for this
      driving_licence_back: null,
    };

    // Add optional fields
    if (email.trim()) {
      formData.email_address = email.trim();
    }
    
    if (gender) {
      formData.gender = gender;
    }
    
    if (location.trim()) {
      formData.location = location.trim();
    }
    
    if (aadhar.trim()) {
      formData.aadhaar_number = aadhar.trim();
    }

    console.log('Saving driver with data:', formData);

    try {
      const result = await driverManagementAPI.createDriver(formData);
      
      if (result.success) {
        toast.success('Driver added successfully!');
        // Reset form
        resetForm();
      } else {
        toast.error(result.error || 'Failed to add driver');
      }
    } catch (error) {
      console.error('Error in saveDriver:', error);
      toast.error('Error saving driver');
    }
  };

  const resetForm = () => {
    setFirstName('');
    setLastName('');
    setEmail('');
    setGender('');
    setDob('');
    setMobile('');
    setLocation('');
    setLicense('');
    setAadhar('');
    setPhoto(null);
    setOtp(['', '', '', '', '', '']);
    setIsVerified(false);
    setOtpLog(null);
    setShowOtp(false);
  };

  // ================= RESEND OTP =================
  const resendOtp = async () => {
    if (isRequestingOtp) return;
    await sendOtp();
  };

  return (
    <div className="min-h-screen bg-white">
      {/* HEADER */}
      <div className="flex items-center border-b px-4 py-4">
        <Link to="/drivers">
          <FiChevronLeft size={22} className="text-gray-600" />
        </Link>
        <h1 className="flex-1 text-center text-lg font-semibold">Add Driver</h1>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* PROFILE PHOTO */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-gray-100 border-2 border-gray-200 overflow-hidden flex items-center justify-center">
              {photo ? (
                <img src={photo} className="w-full h-full object-cover" alt="Driver" />
              ) : (
                <span className="text-4xl text-gray-400">👤</span>
              )}
            </div>
            <button
              onClick={openCamera}
              disabled={cameraOpen}
              className="absolute bottom-0 right-0 w-8 h-8 bg-[#21409A] rounded-full flex items-center justify-center hover:bg-[#1a357d] transition-colors disabled:opacity-50"
            >
              <FiCamera className="text-white" size={14} />
            </button>
          </div>
        </div>

        {/* FORM GRID - 3 COLUMNS */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {/* ROW 1 */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">First Name *</label>
            <Input 
              placeholder="Enter first name" 
              value={firstName} 
              onChange={e => setFirstName(e.target.value)}
              className="h-11"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Last Name *</label>
            <Input 
              placeholder="Enter last name" 
              value={lastName} 
              onChange={e => setLastName(e.target.value)}
              className="h-11"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Email (optional)</label>
            <Input 
              type="email"
              placeholder="Enter email address" 
              value={email} 
              onChange={e => setEmail(e.target.value)}
              className="h-11"
            />
          </div>

          {/* ROW 2 */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Gender</label>
            <select
              value={gender}
              onChange={(e) => setGender(e.target.value)}
              className="h-11 w-full border border-gray-300 rounded-lg px-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#21409A] focus:border-transparent"
            >
              <option value="">Select</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Date of Birth *</label>
            <Input 
              type="date" 
              value={dob} 
              onChange={e => setDob(e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              className="h-11"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Current Location</label>
            <div className="relative">
              <FiMapPin className="absolute left-3 top-3.5 text-gray-400" />
              <Input 
                className="pl-9 h-11" 
                placeholder="Enter city or area" 
                value={location} 
                onChange={e => setLocation(e.target.value)}
              />
            </div>
          </div>

          {/* ROW 3 */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Mobile Number *</label>
            <div className="flex gap-2">
              <Input
                placeholder="Enter mobile number"
                value={mobile}
                onChange={e => {
                  const value = e.target.value.replace(/\D/g, '');
                  if (value.length <= 10) {
                    setMobile(value);
                    if (isVerified) {
                      setIsVerified(false);
                      setOtpLog(null);
                      setShowOtp(false);
                    }
                  }
                }}
                disabled={isVerified}
                className="h-11 flex-1"
              />
              {!isVerified ? (
                <button 
                  onClick={sendOtp}
                  disabled={isRequestingOtp || mobile.length !== 10}
                  className="px-4 h-11 bg-[#21409A] text-white rounded-lg font-medium hover:bg-[#1a357d] transition-colors whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isRequestingOtp ? 'Sending...' : 'Send OTP'}
                </button>
              ) : (
                <div className="flex items-center justify-center px-4 h-11 bg-green-100 text-green-700 rounded-lg font-medium">
                  ✓ Verified
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Driving License Number *</label>
            <Input 
              placeholder="Enter license number" 
              value={license} 
              onChange={e => setLicense(e.target.value)}
              className="h-11"
            />
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">Aadhar Number</label>
            <Input 
              placeholder="Enter Aadhar number" 
              value={aadhar} 
              onChange={e => {
                const value = e.target.value.replace(/\D/g, '');
                if (value.length <= 12) {
                  setAadhar(value);
                }
              }}
              className="h-11"
            />
          </div>
        </div>

        {/* OTP SECTION - SHOWS WHEN Send OTP IS CLICKED */}
        {showOtp && !isVerified && (
          <div className="mb-6 p-6 bg-gray-50 rounded-lg border border-gray-200">
            <div className="mb-4">
              <h3 className="text-sm font-medium text-gray-700">Enter OTP</h3>
              <p className="text-xs text-gray-500 mt-1">Enter the 6-digit OTP sent to {mobile}</p>
            </div>
            
            <div className="flex items-center gap-4">
              {/* 6 OTP BOXES */}
              <div className="flex gap-3 flex-1">
                {[0, 1, 2, 3, 4, 5].map((index) => (
                  <input
                    key={index}
                    ref={(el) => {
                      otpRefs.current[index] = el;
                    }}
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={1}
                    value={otp[index]}
                    onChange={(e) => handleOtpChange(index, e.target.value)}
                    onKeyDown={(e) => handleOtpKeyDown(index, e)}
                    className="w-14 h-14 border border-gray-300 rounded-lg text-center text-2xl font-semibold focus:outline-none focus:ring-2 focus:ring-[#21409A] focus:border-transparent"
                    disabled={isVerifyingOtp}
                    autoFocus={index === 0}
                  />
                ))}
              </div>
              
              {/* VERIFY BUTTON (Arrow) - ALWAYS VISIBLE */}
              <button
                onClick={verifyOtp}
                disabled={isVerifyingOtp || otp.join('').length !== 6}
                className="w-14 h-14 rounded-full bg-[#21409A] flex items-center justify-center hover:bg-[#1a357d] transition-colors flex-shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isVerifyingOtp ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <FiArrowRight className="text-white" size={24} />
                )}
              </button>
            </div>
            
            {/* RESEND OTP */}
            <div className="mt-4 text-center">
              <button 
                onClick={resendOtp}
                disabled={isRequestingOtp}
                className="text-sm text-[#21409A] font-medium hover:underline disabled:opacity-50"
              >
                {isRequestingOtp ? 'Resending...' : "Didn't receive OTP? Resend"}
              </button>
            </div>
          </div>
        )}

        {/* BOTTOM ACTIONS */}
        <div className="flex items-center justify-end mt-8 pt-6 border-t">
          <button
            onClick={saveDriver}
            disabled={!isVerified}
            className="px-8 py-3 bg-[#21409A] text-white rounded-lg font-medium hover:bg-[#1a357d] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Save Driver
          </button>
        </div>
      </div>

      {/* CAMERA MODAL */}
      {cameraOpen && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Take Profile Photo</h3>
            <video 
              ref={videoRef} 
              className="w-full h-64 bg-black rounded-lg mb-6 object-cover"
              autoPlay
              playsInline
              muted
            />
            <div className="flex gap-4 justify-center">
              <button 
                onClick={closeCamera}
                className="px-6 py-2.5 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={capturePhoto}
                className="px-6 py-2.5 bg-[#21409A] text-white rounded-lg font-medium hover:bg-[#1a357d] transition-colors"
              >
                Capture
              </button>
            </div>
          </div>
        </div>
      )}

      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default DriverManagement;