import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Calendar } from "lucide-react";
import { toast } from "sonner";
import { FiChevronLeft } from "react-icons/fi";

// Custom components
import { Button } from "../common/Button";
import ProfileApiService, { BasicProfileData } from "../../services/profileApi";
import { useAuth } from "../../contexts/AuthContext";

// Your custom Label component
const Label = ({ 
  htmlFor, 
  className = "", 
  children 
}: { 
  htmlFor?: string; 
  className?: string; 
  children: React.ReactNode 
}) => {
  return (
    <label 
      htmlFor={htmlFor} 
      className={`text-sm font-medium text-gray-800 ${className}`}
    >
      {children}
    </label>
  );
};

// Your custom Switch component
const Switch = ({
  checked,
  onChange,
  label
}: {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
}) => {
  return (
    <div className="flex items-center gap-3">
      <button
        type="button"
        onClick={() => onChange(!checked)}
        className="relative inline-flex items-center cursor-pointer"
        disabled={false}
      >
        <div
          className={`relative w-14 h-7 rounded-full transition-colors duration-300 ${
            checked ? "bg-primary" : "bg-gray-300"
          }`}
        >
          <div
            className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow-sm transition-transform duration-300 ${
              checked ? "translate-x-8" : "translate-x-1"
            }`}
          />
        </div>
      </button>
      {label && (
        <span className="text-sm text-gray-600">
          {checked ? "Yes" : "No"}
        </span>
      )}
    </div>
  );
};

// Custom Input component
const Input = ({
  id,
  type = "text",
  placeholder,
  value,
  onChange,
  className = "",
  disabled = false
}: {
  id?: string;
  type?: string;
  placeholder?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  className?: string;
  disabled?: boolean;
}) => {
  return (
    <input
      id={id}
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      disabled={disabled}
      className={`w-full px-4 py-3 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    />
  );
};

// Custom Select component
const Select = ({
  id,
  value,
  onChange,
  options,
  placeholder,
  className = "",
  disabled = false
}: {
  id?: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: Array<{ value: string; label: string }>;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}) => {
  return (
    <select
      id={id}
      value={value}
      onChange={onChange}
      disabled={disabled}
      className={`w-full px-4 py-3 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/30 disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
    >
      {placeholder && (
        <option value="">{placeholder}</option>
      )}
      {options.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
};

const BasicDetails = () => {
  const navigate = useNavigate();
  const { user, updateUser } = useAuth();
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    gender: "male" as "male" | "female" | "others",
    dateOfBirth: "",
    location: "",
    // New fields
    publishRide: false,
    partnerType: "" as "" | "individual" | "commercial",
    businessName: "",
    professionalType: "",
    multiVehicle: false,
    workingProfessional: false, // NEW FIELD: Add workingProfessional
  });

  const professionalTypes = [
    { value: "it", label: "Information Technology (IT)" },
    { value: "healthcare", label: "Healthcare Services" },
    { value: "education", label: "Education & Training" },
    { value: "business", label: "Business & Consulting" },
    { value: "engineering", label: "Engineering & Technical Services" },
  ];

  // Fetch profile data on component mount
  useEffect(() => {
    fetchProfileData();
  }, []);

  const fetchProfileData = async () => {
    try {
      setFetching(true);
      console.log("Fetching profile data...");
      
      const result = await ProfileApiService.getBasicProfile();
      
      if (result.success && result.data) {
        console.log("Profile data loaded:", result.data);
        
        // Set form data from API response
        setFormData({
          firstName: result.data.firstName || "",
          lastName: result.data.lastName || "",
          gender: result.data.gender || "male",
          dateOfBirth: result.data.dateOfBirth || "",
          location: result.data.location || "",
          publishRide: result.data.publishRide || false,
          partnerType: result.data.partnerType || "",
          businessName: result.data.businessName || "",
          professionalType: result.data.professionalType || "",
          multiVehicle: result.data.multiVehicle || false,
          // Handle workingProfessional - convert from string to boolean
          workingProfessional: result.data.workingProfessional === true || 
                              result.data.workingProfessional === "true" || 
                              result.data.workingProfessional === "1",
        });
        
        toast.success("Profile loaded successfully");
      } else {
        console.error("Failed to load profile:", result.error);
        toast.error(result.error || "Failed to load profile data");
        
        // If user data exists in auth context, use it as fallback
        if (user) {
          setFormData({
            firstName: user.first_name || "",
            lastName: user.last_name || "",
            gender: (user.gender as "male" | "female" | "others") || "male",
            dateOfBirth: user.date_of_birth || "",
            location: "",
            publishRide: false,
            partnerType: "",
            businessName: "",
            professionalType: "",
            multiVehicle: false,
            workingProfessional: false,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching profile:", error);
      toast.error("An error occurred while loading profile");
    } finally {
      setFetching(false);
    }
  };

  const handleSave = async () => {
    if (!formData.firstName || !formData.lastName) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Validation for commercial partner type
    if (formData.publishRide && formData.partnerType === "commercial" && !formData.businessName) {
      toast.error("Business name is required for commercial partner");
      return;
    }

    // Validation for individual partner type - workingProfessional toggle is required
    if (formData.publishRide && formData.partnerType === "individual") {
      // Note: workingProfessional is a boolean toggle, so no need to check for empty
      // The API expects true/false value
      console.log("Individual partner - workingProfessional:", formData.workingProfessional);
    }

    // Validation for partner type when publishRide is true
    if (formData.publishRide && !formData.partnerType) {
      toast.error("Please select a partner type when publishing rides");
      return;
    }

    try {
      setLoading(true);
      console.log("Saving profile data:", formData);
      
      // Create FormData object for the update using the service method
      const formDataObj = ProfileApiService.createProfileFormData({
        firstName: formData.firstName,
        lastName: formData.lastName,
        dateOfBirth: formData.dateOfBirth,
        gender: formData.gender,
        multiVehicle: formData.multiVehicle,
        publishRide: formData.publishRide,
        partnerType: formData.partnerType,
        businessName: formData.businessName,
        location: formData.location,
        // Add workingProfessional for individual partners
        workingProfessional: formData.partnerType === "individual" ? formData.workingProfessional : false,
      });
      
      console.log("FormData keys:", Array.from(formDataObj.keys()));
      
      // Update profile
      const result = await ProfileApiService.updateBasicProfile(formDataObj);
      
      if (result.success) {
        toast.success(result.message || "Your details have been saved successfully!");
        
        // Update user in auth context
        const userUpdateData: any = {
          first_name: formData.firstName,
          last_name: formData.lastName,
          gender: formData.gender,
          date_of_birth: formData.dateOfBirth,
        };
        
        updateUser(userUpdateData);
        
        // Navigate back after successful save
        setTimeout(() => navigate(-1), 1000);
      } else {
        toast.error(result.error || "Failed to save profile");
      }
    } catch (error) {
      console.error("Error saving profile:", error);
      toast.error("An error occurred while saving");
    } finally {
      setLoading(false);
    }
  };

  // Handle publish ride toggle
  const handlePublishRideToggle = (checked: boolean) => {
    const newFormData = {
      ...formData,
      publishRide: checked,
      // Reset partner type and related fields when turning off publish ride
      partnerType: checked ? formData.partnerType : "",
      businessName: checked ? formData.businessName : "",
      professionalType: checked ? formData.professionalType : "",
      workingProfessional: checked ? formData.workingProfessional : false,
      multiVehicle: checked ? formData.multiVehicle : false,
    };
    
    setFormData(newFormData);
  };

  // Handle partner type change
  const handlePartnerTypeChange = (type: "individual" | "commercial") => {
    setFormData({
      ...formData,
      partnerType: type,
      // Clear fields based on selection
      businessName: type === "commercial" ? formData.businessName : "",
      professionalType: type === "individual" ? formData.professionalType : "",
      // Reset workingProfessional when changing partner type
      workingProfessional: type === "individual" ? formData.workingProfessional : false,
    });
  };

  // Handle multiVehicle toggle
  const handleMultiVehicleToggle = (checked: boolean) => {
    setFormData({
      ...formData,
      multiVehicle: checked,
    });
  };

  // Handle workingProfessional toggle
  const handleWorkingProfessionalToggle = (checked: boolean) => {
    setFormData({
      ...formData,
      workingProfessional: checked,
    });
  };

  const genderOptions = ["male", "female", "others"];

  if (fetching) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading profile data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="flex items-center justify-center bg-white px-4 py-4 relative shadow-sm">
        <button 
          onClick={() => navigate(-1)} 
          className="absolute left-4 p-2 rounded-lg hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={loading}
        >
          <FiChevronLeft size={24} className="text-foreground" />
        </button>
        <h1 className="text-lg font-semibold text-gray-800">Basic details</h1>
      </div>

      {/* Subtitle */}
      <p className="text-center text-sm text-gray-600 mt-2 mb-6">
        Make sure your personal information is accurate.
      </p>

      {/* Form Card */}
      <div className="px-4 md:px-8 lg:px-16">
        <div className="bg-white rounded-xl shadow-sm p-6 md:p-8 max-w-3xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
            {/* Left Column */}
            <div className="space-y-6">
              {/* First Name */}
              <div className="space-y-2">
                <Label htmlFor="firstName">
                  First name
                </Label>
                <Input
                  id="firstName"
                  placeholder="Enter your first name"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  className="h-12"
                  disabled={loading}
                />
              </div>

              {/* Last Name */}
              <div className="space-y-2">
                <Label htmlFor="lastName">
                  Last name
                </Label>
                <Input
                  id="lastName"
                  placeholder="Enter your last name"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  className="h-12"
                  disabled={loading}
                />
              </div>

              {/* Date of Birth and Location in same row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Date of Birth */}
                <div className="space-y-2">
                  <Label htmlFor="dob">
                    Date of birth
                  </Label>
                  <div className="relative">
                    <Input
                      id="dob"
                      type="date"
                      value={formData.dateOfBirth}
                      onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                      className="h-12 pr-10"
                      disabled={loading}
                    />
                    <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400 pointer-events-none" />
                  </div>
                </div>

                {/* Location (Optional) */}
                <div className="space-y-2">
                  <Label htmlFor="location">
                    Location (Optional)
                  </Label>
                  <Input
                    id="location"
                    placeholder="Enter your location"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="h-12"
                    disabled={loading}
                  />
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Gender */}
              <div className="space-y-3">
                <Label>Gender</Label>
                <div className="flex gap-2 flex-wrap">
                  {genderOptions.map((option) => (
                    <button
                      key={option}
                      type="button"
                      onClick={() => setFormData({ ...formData, gender: option as "male" | "female" | "others" })}
                      className={`px-6 py-2 rounded-full text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                        formData.gender === option
                          ? "bg-primary text-white hover:bg-primary/90"
                          : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                      }`}
                      disabled={loading}
                    >
                      {option.charAt(0).toUpperCase() + option.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Publish Ride Toggle */}
              <div className="space-y-3">
                <Label>
                  Do you want to publish a ride?
                </Label>
                <Switch
                  checked={formData.publishRide}
                  onChange={handlePublishRideToggle}
                  label={formData.publishRide ? "Yes" : "No"}
                />
                <p className="text-xs text-gray-500">
                  {formData.publishRide 
                    ? "You want to publish rides as a partner"
                    : "You don't want to publish rides"}
                </p>
              </div>

              {/* Partner Type Selection (Only shown when publishRide is true) */}
              {formData.publishRide && (
                <>
                  <div className="space-y-3">
                    <Label>Partner Type</Label>
                    <div className="flex gap-4">
                      <button
                        type="button"
                        onClick={() => handlePartnerTypeChange("individual")}
                        className={`px-6 py-3 rounded-lg flex-1 text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                          formData.partnerType === "individual"
                            ? "bg-primary text-white hover:bg-primary/90"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                        disabled={loading}
                      >
                        Individual
                      </button>
                      <button
                        type="button"
                        onClick={() => handlePartnerTypeChange("commercial")}
                        className={`px-6 py-3 rounded-lg flex-1 text-sm font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                          formData.partnerType === "commercial"
                            ? "bg-primary text-white hover:bg-primary/90"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }`}
                        disabled={loading}
                      >
                        Commercial
                      </button>
                    </div>
                    <p className="text-xs text-gray-500">
                      Select your partner type to continue
                    </p>
                  </div>

                  {/* MultiVehicle Toggle (Only shown when publishRide is true) */}
                  <div className="space-y-3">
                    <Label>
                      Multiple Vehicles
                    </Label>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-700">
                          Do you have multiple vehicles?
                        </p>
                        <p className="text-xs text-gray-500 mt-1">
                          {formData.multiVehicle 
                            ? "You can manage multiple vehicles" 
                            : "You have single vehicle access"}
                        </p>
                      </div>
                      <Switch
                        checked={formData.multiVehicle}
                        onChange={handleMultiVehicleToggle}
                      />
                    </div>
                  </div>

                  {/* Working Professional Toggle (Only for Individual partners) */}
                  {formData.partnerType === "individual" && (
                    <div className="space-y-3">
                      <Label>
                        Working Professional
                      </Label>
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-700">
                            Are you a working professional?
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {formData.workingProfessional 
                              ? "You are registered as a working professional" 
                              : "You are not a working professional"}
                          </p>
                        </div>
                        <Switch
                          checked={formData.workingProfessional}
                          onChange={handleWorkingProfessionalToggle}
                        />
                      </div>
                    </div>
                  )}

                  {/* Business Name Field (Only for Commercial partners) */}
                  {formData.partnerType === "commercial" && (
                    <div className="space-y-2">
                      <Label htmlFor="businessName">
                        Business Name <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        id="businessName"
                        placeholder="Enter your business name"
                        value={formData.businessName}
                        onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                        className="h-12"
                        disabled={loading}
                      />
                      <p className="text-xs text-gray-500">
                        Required for commercial partners
                      </p>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Save Button */}
          <div className="flex justify-end mt-8">
            <Button
              onClick={handleSave}
              variant="default"
              size="default"
              className="px-8 py-3 rounded-full"
              disabled={loading || !formData.firstName || !formData.lastName}
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </>
              ) : (
                "Save details"
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BasicDetails;