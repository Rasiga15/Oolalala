import { useState } from "react";
import { RideCard, RideData } from "../components/Myride/ridecard";
import { RideDetails } from "../components/Myride/ridedeatils";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Navbar } from "@/components/layout/Navbar"; // Import your Navbar

const mockRides: RideData[] = [
  {
    id: "1",
    from: "Chennai",
    to: "Salem",
    date: "Jul 20, 2025",
    time: "09:00-12:00PM",
    distance: "32 Km",
    driverName: "Chris James",
    driverVerified: true,
    price: 2320,
    status: "upcoming",
    seats: 1,
    preference: "Ladies Only",
    vehicle: "Hyundai Creta",
    vehicleNumber: "TN 09 AB 8533",
    stops: [{ name: "Salem", distance: "140 km", price: 300 }],
  },
  {
    id: "2",
    from: "Chennai",
    to: "Coimbatore",
    date: "Jul 18, 2025",
    time: "12:00-03:00PM",
    distance: "21 Km",
    driverName: "Angelina Mary",
    driverVerified: true,
    price: 1532,
    status: "completed",
    seats: 2,
    preference: "Anyone",
    vehicle: "Toyota Innova",
    vehicleNumber: "TN 11 CD 1234",
    stops: [
      { name: "Vellore", distance: "130 km", price: 200 },
      { name: "Coimbatore", distance: "300 km", price: 1332 },
    ],
  },
  {
    id: "3",
    from: "Chennai",
    to: "Madurai",
    date: "Jul 15, 2025",
    time: "10:35-02:00PM",
    distance: "19 Km",
    driverName: "John Smith",
    driverVerified: true,
    price: 2320,
    status: "completed",
    seats: 1,
    preference: "Anyone",
    vehicle: "Maruti Swift",
    vehicleNumber: "TN 07 EF 5678",
    stops: [
      { name: "Trichy", distance: "320 km", price: 1500 },
      { name: "Madurai", distance: "460 km", price: 820 },
    ],
  },
];

interface MyRidesPanelProps {
  onClose?: () => void;
}

export function MyRidesPanel({ onClose }: MyRidesPanelProps) {
  const [selectedRide, setSelectedRide] = useState<RideData>(mockRides[0]); // Default to first ride
  const [filter, setFilter] = useState<string>("all");

  const filteredRides = mockRides.filter((ride) => {
    if (filter === "all") return true;
    return ride.status === filter;
  });

  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <Navbar />
      
      {/* Main Content */}
      <div className="pt-16"> {/* Add padding-top for navbar */}
        <div className="flex h-[calc(100vh-64px)] animate-fade-in">
          {/* Left Panel - Ride List */}
          <div className="flex h-full w-full flex-col border-r border-border lg:w-1/2">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-border p-4 lg:p-6">
              <h1 className="text-lg font-bold text-foreground lg:text-xl">
                Your past and upcoming trips
              </h1>
              <div className="flex items-center gap-3">
                <Select value={filter} onValueChange={setFilter}>
                  <SelectTrigger className="w-28">
                    <SelectValue placeholder="Filter" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="upcoming">Upcoming</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Ride List */}
            <div className="flex-1 space-y-3 overflow-y-auto p-3 lg:p-5"> {/* Reduced padding */}
              {filteredRides.map((ride) => (
                <RideCard
                  key={ride.id}
                  ride={ride}
                  isSelected={selectedRide?.id === ride.id}
                  onClick={() => setSelectedRide(ride)}
                />
              ))}
            </div>
          </div>

          {/* Right Panel - Ride Details */}
          <div className="hidden h-full w-1/2 lg:block">
            {selectedRide ? (
              <RideDetails
                ride={selectedRide}
                onClose={() => setSelectedRide(mockRides[0])} // Reset to first ride on close
              />
            ) : (
              <div className="flex h-full items-center justify-center bg-muted/30">
                <p className="text-muted-foreground">
                  Select a ride to view details
                </p>
              </div>
            )}
          </div>

          {/* Mobile Details Modal */}
          {selectedRide && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div
                className="absolute inset-0 bg-foreground/20"
                onClick={() => setSelectedRide(mockRides[0])} // Reset to first ride on close
              />
              <div className="absolute bottom-0 left-0 right-0 max-h-[85vh] overflow-hidden rounded-t-2xl bg-card shadow-xl">
                <RideDetails
                  ride={selectedRide}
                  onClose={() => setSelectedRide(mockRides[0])} // Reset to first ride on close
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}